"""FastAPI dependency injection providers."""

from functools import lru_cache
from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession

from app.core.config.base import BaseAppSettings, get_settings
from app.core.security.jwt import JWTConfig
from app.core.security.password import PasswordHasher
from app.database.engine import get_engine
from app.database.session import get_db_session
from app.services.health import HealthService
from app.services.redis import RedisService


def get_app_settings() -> BaseAppSettings:
    """Provide application settings."""
    return get_settings()


SettingsDep = Annotated[BaseAppSettings, Depends(get_app_settings)]


def get_redis_service(request: Request) -> RedisService:
    """Provide Redis service from application state."""
    return request.app.state.redis_service


RedisDep = Annotated[RedisService, Depends(get_redis_service)]


def get_db_engine(request: Request) -> AsyncEngine:
    """Provide database engine from application state."""
    return request.app.state.engine


EngineDep = Annotated[AsyncEngine, Depends(get_db_engine)]


DbSessionDep = Annotated[AsyncSession, Depends(get_db_session)]


def get_health_service(
    settings: SettingsDep,
    engine: EngineDep,
    redis: RedisDep,
) -> HealthService:
    """Provide health check service."""
    return HealthService(settings=settings, engine=engine, redis_service=redis)


HealthServiceDep = Annotated[HealthService, Depends(get_health_service)]


@lru_cache
def get_jwt_config() -> JWTConfig:
    """Provide JWT configuration singleton."""
    return JWTConfig(get_settings())


JWTConfigDep = Annotated[JWTConfig, Depends(get_jwt_config)]


@lru_cache
def get_password_hasher() -> PasswordHasher:
    """Provide password hasher singleton."""
    return PasswordHasher()


PasswordHasherDep = Annotated[PasswordHasher, Depends(get_password_hasher)]
