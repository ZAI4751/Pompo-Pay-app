"""Password hashing utilities."""

from passlib.context import CryptContext


class PasswordHasher:
    """Secure password hashing using bcrypt."""

    def __init__(self) -> None:
        self._context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    def hash(self, password: str) -> str:
        """Hash a plaintext password."""
        return self._context.hash(password)

    def verify(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a plaintext password against a hash."""
        return self._context.verify(plain_password, hashed_password)
