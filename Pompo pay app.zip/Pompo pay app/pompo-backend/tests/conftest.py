"""Pytest configuration and shared fixtures."""

import os
from collections.abc import AsyncGenerator

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine

os.environ["APP_ENV"] = "testing"
os.environ["ALLOWED_HOSTS"] = "*"
os.environ["SECRET_KEY"] = "test-secret-key-minimum-32-characters-long-for-testing"
os.environ["JWT_SECRET_KEY"] = "test-jwt-secret-key-minimum-32-characters-long"
os.environ["DATABASE_URL"] = "postgresql+asyncpg://pompo:pompo_secret@localhost:5432/pompo_test"
os.environ["REDIS_URL"] = "redis://localhost:6379/0"
os.environ["CELERY_BROKER_URL"] = "redis://localhost:6379/1"
os.environ["CELERY_RESULT_BACKEND"] = "redis://localhost:6379/2"

from app.core.config.base import get_settings  # noqa: E402
from app.main import create_app  # noqa: E402


@pytest.fixture(scope="session")
def settings():
    """Provide test settings."""
    get_settings.cache_clear()
    return get_settings()


@pytest.fixture
async def app(settings):
    """Provide a fresh FastAPI application instance."""
    get_settings.cache_clear()
    application = create_app()
    yield application
    await application.state.redis_service.close()


@pytest.fixture
async def client(app) -> AsyncGenerator[AsyncClient, None]:
    """Provide an async HTTP test client."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.fixture
async def db_engine(settings) -> AsyncGenerator[AsyncEngine, None]:
    """Provide a database engine for integration tests."""
    engine = create_async_engine(settings.database_url_str, pool_pre_ping=True)
    yield engine
    await engine.dispose()


@pytest.fixture
async def db_session(db_engine) -> AsyncGenerator[AsyncSession, None]:
    """Provide a database session for integration tests."""
    from sqlalchemy.ext.asyncio import async_sessionmaker

    factory = async_sessionmaker(db_engine, expire_on_commit=False)
    async with factory() as session:
        yield session
