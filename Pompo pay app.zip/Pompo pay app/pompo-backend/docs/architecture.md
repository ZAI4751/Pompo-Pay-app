# POMPO Backend — Architecture Overview

## System Context

POMPO is a payment bridge for Malawi that connects retail POS systems to Airtel Money, TNM Mpamba, and bank payment rails. It routes payment requests and monitors settlements without storing customer funds.

## Architecture Diagram

```mermaid
graph TB
    subgraph Client Layer
        POS[POS Systems]
        Admin[Admin Dashboard]
    end

    subgraph API Layer
        FastAPI[FastAPI Application]
        MW[Middleware Stack]
        V1["/api/v1 Routes"]
    end

    subgraph Application Layer
        Services[Services]
        Events[Events]
        Tasks[Celery Tasks]
    end

    subgraph Domain Layer
        Payments[Payments Module]
        Auth[Authentication]
        Providers[Payment Providers]
    end

    subgraph Infrastructure Layer
        Repos[Repositories]
        DB[(PostgreSQL)]
        Redis[(Redis)]
        Celery[Celery Workers]
    end

    POS --> FastAPI
    Admin --> FastAPI
    FastAPI --> MW
    MW --> V1
    V1 --> Services
    Services --> Repos
    Services --> Redis
    Services --> Tasks
    Tasks --> Celery
    Celery --> Redis
    Repos --> DB
    Services --> Payments
    Services --> Auth
    Payments --> Providers
```

## Layer Responsibilities

| Layer | Responsibility |
|-------|---------------|
| **API** | HTTP routing, request validation, response serialization |
| **Services** | Business logic orchestration |
| **Repositories** | Data access abstraction |
| **Models** | SQLAlchemy ORM entities |
| **Schemas** | Pydantic request/response models |
| **Middleware** | Cross-cutting concerns (logging, CORS, rate limiting) |
| **Workers** | Background task processing via Celery |

## Request Flow

```mermaid
sequenceDiagram
    participant Client
    participant Middleware
    participant Router
    participant Service
    participant Repository
    participant Database

    Client->>Middleware: HTTP Request
    Middleware->>Middleware: Assign Request ID
    Middleware->>Middleware: Rate Limit Check
    Middleware->>Router: Forward Request
    Router->>Service: Call Service Method
    Service->>Repository: Data Operation
    Repository->>Database: SQL Query
    Database-->>Repository: Result
    Repository-->>Service: Domain Object
    Service-->>Router: Response Data
    Router-->>Middleware: JSON Response
    Middleware->>Middleware: Log Request
    Middleware-->>Client: HTTP Response
```

## Dependency Injection

All dependencies flow through FastAPI's `Depends()` system:

- **Settings** → loaded from environment via Pydantic BaseSettings
- **Database Session** → async session per request
- **Redis Service** → shared connection pool
- **Services** → constructed with injected dependencies

## Environment Configuration

Three environment profiles are supported:

- **Development** — debug logging, console output, relaxed validation
- **Testing** — minimal logging, isolated database
- **Production** — JSON logging, strict secret validation

Set `APP_ENV=development|testing|production` to select the profile.

---

## M002 — Domain Model & Database

Fifteen core entities are now mapped under `app/models/`, split by bounded
area rather than one giant file:

- `app/models/base.py` — declarative `Base`, a portable `GUID` type
  (native `UUID` on PostgreSQL, hex-string `CHAR(32)` elsewhere so the model
  layer is unit-testable against SQLite), and `TimestampMixin` /
  `SoftDeleteMixin`.
- `app/models/organization.py` — Merchant, Branch, Till.
- `app/models/user.py` — User, Role, Permission, RolePermission.
- `app/models/payment.py` — PaymentProvider, Transaction, PaymentAttempt,
  WebhookEvent, QRCode, Receipt.
- `app/models/audit.py` — APIKey, AuditLog.
- `app/models/enums.py` — `TransactionStatus`, `PaymentAttemptStatus`,
  `ProviderCode`, `UserRoleCode`.

### Design decisions

- **UUID primary keys everywhere**, generated client-side (`default=uuid4`)
  rather than relying on a DB default, so IDs are available before flush.
- **Soft delete is opt-in and explicit.** `SoftDeleteMixin` adds
  `deleted_at`; nothing filters it out automatically. Repositories that want
  "active only" semantics call `BaseRepository.get_active_by_id`.
  `AuditLog` deliberately does **not** get soft delete or `updated_at` —
  audit rows must never be mutated or hidden.
- **No provider-specific logic lives in these models.** `PaymentProvider`
  and `PaymentAttempt` are storage shape only; the adapter pattern that
  turns "call Airtel Money" into a real HTTP call is a later milestone
  (M008+).
- **RolePermission is a full entity**, not a bare association table, so
  grants can carry `granted_at` and future audit metadata.

### Verification performed

- `configure_mappers()` succeeds — every relationship resolves.
- `Base.metadata.create_all()` succeeds against SQLite (portability check).
- `tests/test_models.py` (4 tests) exercises the full checkout relationship
  chain, a unique-constraint violation, one-to-one QR/Receipt links, and
  soft-delete query filtering — all passing.
- The initial Alembic revision (`migrations/versions/0001_initial_domain_schema.py`)
  was cross-checked line-by-line against
  `CreateTable(...).compile(dialect=postgresql.dialect())` output for every
  table. It was **not** run against a live PostgreSQL instance (none is
  reachable from the environment this was built in) — run
  `docker compose up -d db && alembic upgrade head && alembic check` before
  trusting it in a real environment.

### Known limitations / next milestone

- No repository or service classes for these entities yet beyond the
  generic `BaseRepository` helpers — that is M005/M006/M007 (Merchant,
  Branch, Till/Cashier management).
- No seed data yet (M016 area) and no transaction *state machine*
  enforcement yet (M011) — the DB will currently accept any status value in
  the enum regardless of what state preceded it.
